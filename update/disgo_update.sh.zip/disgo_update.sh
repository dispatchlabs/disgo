sleep 2
rm -rf *.zip
